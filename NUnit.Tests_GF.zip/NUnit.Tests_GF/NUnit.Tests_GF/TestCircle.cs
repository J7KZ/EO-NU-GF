﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NUnit.Tests_GF
{
    [TestFixture]
    public class TestCircle
    {
        
        [Test, TestCaseSource("RadCirData")]
        public void TestCirArea(int r)
        {
            GeometricFigures.Circle Crcl = new GeometricFigures.Circle(r);
            double GFACir = Crcl.getAreaCircle();
            double CA = Math.PI * Math.Pow(r,2);
            //double CA1 = Math.PI * r*r; // на 11,17,21,22 тесты тоже не выполняются
            Assert.AreEqual(CA, GFACir, "Error r= {0}, Вычисление1 {1} - Проверка {2}", r, CA, GFACir);
        }

        [Test, TestCaseSource("RadCirData")]        
        public void TestCirLen(int r)
        {
            GeometricFigures.Circle Crcl = new GeometricFigures.Circle(r);
            double GFLCir = Crcl.getLengthCircle();
            double CL = Math.PI * r * 2;
            Assert.AreEqual(CL, GFLCir, "Error r= {0}, Вычисление {1} - Проверка {2}", r, CL, GFLCir);
        }


        static int[] RadCirData = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25 };
        
              
    }
}

