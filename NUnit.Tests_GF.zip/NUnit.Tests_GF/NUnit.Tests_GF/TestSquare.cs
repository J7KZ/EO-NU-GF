﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NUnit.Tests_GF
{
    [TestFixture]
    public class TestSquare
    {
        [Test, TestCaseSource(typeof(SizeCS), "SizeSqCir")]
        public void TestSqArea(int len)
        {
            GeometricFigures.Square Sqr = new GeometricFigures.Square(len);
            double GFASq = Sqr.getAreaSquare();
            double SqA = Math.Pow(len, 2);
            Assert.AreEqual(SqA, GFASq, "Error len= {0}, Вычисление {1} - Проверка {2}", len, SqA, GFASq);
        }

        [Test, TestCaseSource(typeof(SizeCS), "SizeSqCir")]
        public void TestSqLen(int len)
        {
            GeometricFigures.Square Sqr = new GeometricFigures.Square(len);
            double GFLSq = Sqr.getLengthSquare();
            double SqL = 4 * len;
            Assert.AreEqual(SqL, GFLSq, "Error len= {0}, Вычисление {1} - Проверка {2}", len, SqL, GFLSq);
        }
    }        
}
