﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NUnit.Tests_GF
{
    [TestFixture]
    public class TestClass
    {
        
        //GeometricFigures.Circle Crcl = new GeometricFigures.Circle(r);

        //TestCircle TCir = new TestCircle();
        //TCir.
        //[Test]
        //public void TestMethod()
        //{
        //    // TODO: Add your test code here
        //    Assert.Pass("Your first passing test");
        //}
    }
}
