﻿using NUnit.Framework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NUnit.Tests_GF
{
    class SizeCS
    {
        public static IEnumerable SizeSqCir
        {
            get
            {
                int n = 25;
                for (int i = 1; i <= n; i++)
                {
                    yield return new TestCaseData(i);
                }
            }
        }
    }
}
