﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NUnit.Tests_GF
{
    class GeomFigData
    {
        public static void DataCirRad()
        {
            int[] CirR = new int [r];

            for (int i = 1; i >= 25; i++)
                int r = i;
        }
    }
}
