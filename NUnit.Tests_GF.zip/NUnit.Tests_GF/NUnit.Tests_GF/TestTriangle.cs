﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NUnit.Tests_GF
{
    [TestFixture]
    public class TestTriangle
    {
        [Test, TestCaseSource(typeof(Size), "SizeTr")]
        public void TestTrArea(int s1, int s2, int s3)
        {
            GeometricFigures.Triangle Trngl = new GeometricFigures.Triangle(s1, s2, s3);
            if (s1 + s2 > s3 && s1 + s3 > s2 && s2 + s3 > s1)
            {
                double GFATr = Trngl.getAreaTriangle();
                double p = (s1 + s2 + s3) / 2;
                double TrA = Math.Sqrt(p * (p - s1) * (p - s2) * (p - s3));
                Assert.AreEqual(TrA, GFATr, "Error s1= {0}, s2= {1}, s3= {2}. Вычисление {3} - Проверка {4}", s1, s2, s3, TrA, GFATr);
            }
            else
            {
               
                double TrA = 10000; // исключим из невыполенных тестов те где треугольник не существует
                double GFATr = Trngl.getAreaTriangle();
                Assert.AreNotEqual(TrA, GFATr, "Треугольник со сторонами s1= {0}, s2= {1}, s3= {2} не существует. Вычисление {3} - Проверка {4}", s1, s2, s3, TrA, GFATr);
            }


        }

        [Test, TestCaseSource(typeof(Size), "SizeTr")]
        public void TestTrLen(int s1, int s2, int s3)
        {
            GeometricFigures.Triangle Trngl = new GeometricFigures.Triangle(s1, s2, s3);
            if (s1 + s2 > s3 && s1 + s3 > s2 && s2 + s3 > s1)
            {
                double GFLTr = Trngl.getLengthTriangle();
                double TrL = s1 + s2 + s3;
                Assert.AreEqual(TrL, GFLTr, "Error s1= {0}, s2= {1}, s3= {2}. Вычисление {3} - Проверка {4}", s1, s2, s3, TrL, GFLTr);
            }
            else
            {
                int TrL = 1000; // исключим из невыполенных тестов те где треугольник не существует
                double GFLTr = Trngl.getLengthTriangle();
                Assert.AreNotEqual(TrL, GFLTr, "Треугольник со сторонами s1= {0}, s2= {1}, s3= {2} не существует. Вычисление {3} - Проверка {4}", s1, s2, s3, TrL, GFLTr);
            }
        }

    }
}
