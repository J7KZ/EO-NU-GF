﻿using NUnit.Framework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NUnit.Tests_GF
{
    class Size
    {
        public static IEnumerable SizeTr
        {
            get
            {
                int m = 15;
                for (int i = 1; i <= m; i++)
                {
                    for (int j = 1; j <= m; j++)
                    {
                        for (int k = 1; k <= m; k++)
                        {
                            yield return new TestCaseData(i, j, k);
                        }

                    }
                }
            }
        }

    }

}
